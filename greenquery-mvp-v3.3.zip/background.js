
const VERSION = '0.3.2';
const DEFAULTS = { j_per_token: 3.5, pue: 1.2 };
const REGION_CACHE_TTL_MS = 24*3600*1000;
const STORAGE_LIMIT = 50000;

let REGION_MAP = null;

async function loadRegionMap(){ if (REGION_MAP) return REGION_MAP;
  try { const res = await fetch(chrome.runtime.getURL('regions.json')); REGION_MAP = await res.json(); }
  catch(e){ REGION_MAP = { DEFAULT:{ wue_L_per_kWh:0.30, grid_g_per_kWh:400, grid_hourly_factor:new Array(24).fill(1), wue_hourly_factor:new Array(24).fill(1) } }; }
  return REGION_MAP;
}
async function resolveRegionCodeViaIP(){
  const providers = [
    async()=>{ const r=await fetch('https://ipapi.co/json/'); if(!r.ok) throw 0; const j=await r.json(); return j.country_code||null; },
    async()=>{ const r=await fetch('https://ipwho.is/'); if(!r.ok) throw 0; const j=await r.json(); return j.country_code||null; },
    async()=>{ const r=await fetch('https://freegeoip.app/json/'); if(!r.ok) throw 0; const j=await r.json(); return j.country_code||null; },
  ];
  for (const fn of providers){ try{ const code = await fn(); if (code) return code.toUpperCase(); }catch{} }
  return null;
}
function lookupRegion(map, code){
  if (code && code.includes('-')){
    const [c] = code.split('-'); const m = map[c];
    if (m && m.subregions && m.subregions[code]) return m.subregions[code];
  }
  if (code && map[code]) return map[code];
  return map.DEFAULT;
}
async function getRegionFactors(){
  const now = Date.now(); const map = await loadRegionMap();
  const cache = await chrome.storage.local.get(['region_cache','settings']); const settings = cache.settings||{};
  if ((settings.region_source||'auto')==='manual' && settings.region_code){
    const factors = lookupRegion(map, settings.region_code);
    return { code: settings.region_code, ...factors, provider: 'manual' };
  }
  const c = cache.region_cache;
  if (c && (now - (c.resolved_at||0) < (c.ttl_ms||REGION_CACHE_TTL_MS)) && c.wue_L_per_kWh && c.grid_g_per_kWh) return c;
  let code = await resolveRegionCodeViaIP();
  if (!code) { const lang=(navigator.language||'en-US'); code=(lang.split('-')[1]||'DEFAULT').toUpperCase(); }
  const factors = lookupRegion(map, code);
  const region_cache = { code, ...factors, provider:'ip', resolved_at: now, ttl_ms: REGION_CACHE_TTL_MS };
  await chrome.storage.local.set({ region_cache });
  return region_cache;
}
function computeImpact({ tokens_out=300, j_per_token=3.5, pue=1.2, wue_L_per_kWh=0.30, grid_g_per_kWh=400, grid_hourly_factor=null, wue_hourly_factor=null, hour_local=null }){
  const h = (hour_local==null ? (new Date()).getHours() : hour_local);
  const gF = (Array.isArray(grid_hourly_factor) && grid_hourly_factor[h]!=null) ? grid_hourly_factor[h] : 1.0;
  const wF = (Array.isArray(wue_hourly_factor) && wue_hourly_factor[h]!=null) ? wue_hourly_factor[h] : 1.0;
  const joules = j_per_token * Math.max(0,tokens_out);
  const kWh_IT = joules / 3_600_000; const kWh_site = kWh_IT * pue;
  const water_L = kWh_site * (wue_L_per_kWh * wF);
  const co2_g = kWh_site * (grid_g_per_kWh * gF);
  return { water_L, co2_g, kWh_site, hour:h, grid_factor:gF, wue_factor:wF };
}
async function addEvent(evt){
  const store = await chrome.storage.local.get(['events','totalWater','totalCO2']);
  const events = Array.isArray(store.events)?store.events:[]; events.unshift(evt);
  while(events.length>STORAGE_LIMIT) events.pop();
  const totalWater=(store.totalWater||0)+(evt.water_L||0); const totalCO2=(store.totalCO2||0)+(evt.co2_g||0);
  await chrome.storage.local.set({ events, totalWater, totalCO2, lastEventTs: evt.ts });
}
async function setSettings(partial){
  const store = await chrome.storage.local.get(['settings']); const settings = store.settings||{};
  const merged={...settings,...partial}; await chrome.storage.local.set({ settings: merged }); return merged;
}
async function clearAllData(){ await chrome.storage.local.set({ events:[], totalWater:0, totalCO2:0, lastEventTs:null }); }

chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
 (async()=>{
  try {
    switch(msg?.type){
      case 'LIVE_CONSTANTS': {
        const region = await getRegionFactors();
        const settings = (await chrome.storage.local.get(['settings'])).settings||{};
        sendResponse({ ok:true, region, j_per_token: settings.j_per_token||DEFAULTS.j_per_token, pue: settings.pue||DEFAULTS.pue }); return;
      }
      case 'CALCULATE_IMPACT': {
        const region = await getRegionFactors(); const settings=(await chrome.storage.local.get(['settings'])).settings||{};
        const jpt=settings.j_per_token||DEFAULTS.j_per_token; const pue=settings.pue||DEFAULTS.pue;
        const wue = settings.wue_L_per_kWh ?? region.wue_L_per_kWh;
        const grid = settings.grid_g_per_kWh ?? region.grid_g_per_kWh;
        const { site, model, tokens_in=0, tokens_out=0 } = msg;
        const h=(new Date()).getHours();
        const res = computeImpact({ tokens_out, j_per_token:jpt, pue, wue_L_per_kWh:wue, grid_g_per_kWh:grid, grid_hourly_factor:region.grid_hourly_factor, wue_hourly_factor:region.wue_hourly_factor, hour_local:h });
        const evt = { ts:Date.now(), site:site||'unknown', model:model||null, tokens_in, tokens_out, water_L:res.water_L, co2_g:res.co2_g,
          assumptions:{ region_code: region.code, wue_L_per_kWh:wue, grid_g_per_kWh:grid, pue, j_per_token:jpt, hour_local:res.hour, grid_hourly_factor:region.grid_hourly_factor, wue_hourly_factor:region.wue_hourly_factor } };
        await addEvent(evt); sendResponse({ ok:true, evt }); return;
      }
      case 'GET_TOTALS': {
        const { totalWater=0, totalCO2=0 } = await chrome.storage.local.get(['totalWater','totalCO2']);
        sendResponse({ ok:true, totals:{ water: totalWater, co2: totalCO2 } }); return;
      }
      case 'GET_RECENT': {
        const { events=[] } = await chrome.storage.local.get(['events']); const limit = typeof msg.limit==='number'?msg.limit:10;
        sendResponse({ ok:true, events: events.slice(0,limit) }); return;
      }
      case 'GET_HISTORY': {
        const { events=[] } = await chrome.storage.local.get(['events']);
        const { since=0, until=Date.now(), site='all', page=0, pageSize=20, sort='newest' } = msg;
        let rows = events.filter(e=>e.ts>=since && e.ts<=until); if(site!=='all') rows=rows.filter(e=>e.site===site);
        if (sort==='newest') rows.sort((a,b)=>b.ts-a.ts); if (sort==='oldest') rows.sort((a,b)=>a.ts-b.ts);
        if (sort==='water') rows.sort((a,b)=>b.water_L-a.water_L); if (sort==='co2') rows.sort((a,b)=>b.co2_g-a.co2_g);
        const start=page*pageSize; const pageRows=rows.slice(start,start+pageSize);
        const totals=pageRows.reduce((a,r)=>{a.water+=r.water_L; a.co2+=r.co2_g; return a;},{water:0,co2:0});
        sendResponse({ ok:true, rows:pageRows, count:rows.length, page, pageSize, totals }); return;
      }
      case 'GET_SETTINGS': {
        const { settings={} } = await chrome.storage.local.get(['settings']); const region = await getRegionFactors();
        sendResponse({ ok:true, settings, region }); return;
      }
      case 'SET_SETTINGS': {
        const merged = await setSettings(msg.settings||{});
        if (merged.region_source==='manual' && merged.region_code){
          const map = await loadRegionMap(); const f = lookupRegion(map, merged.region_code);
          await chrome.storage.local.set({ region_cache:{ code:merged.region_code, ...f, provider:'manual', resolved_at:Date.now(), ttl_ms:REGION_CACHE_TTL_MS } });
        }
        sendResponse({ ok:true, settings: merged }); return;
      }
      case 'CLEAR_DATA': { await clearAllData(); sendResponse({ ok:true }); return; }
      default: sendResponse({ ok:false, error:'Unknown message type' }); return;
    }
  } catch(e){ console.error('BG error', e); sendResponse({ ok:false, error:String(e) }); }
 })();
 return true;
});
