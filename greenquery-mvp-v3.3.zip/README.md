GreenQuery v0.3.2 — Realtime tracker, analytics, history, settings, and 100-tier fun-liners in Overview.
