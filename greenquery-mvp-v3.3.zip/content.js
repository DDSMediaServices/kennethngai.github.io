
(function(){
  const STATE = { site: detectSite(), model: null, tokens_in: 0, tokens_out: 0, j_per_token: 3.5, pue: 1.2, region: null };
  function detectSite(){ const h=location.hostname;
    if (h.includes('openai.com')||h.includes('chatgpt.com')) return 'chatgpt';
    if (h.includes('anthropic.com')||h.includes('claude.ai')) return 'claude';
    if (h.includes('gemini.google.com')) return 'gemini';
    return 'unknown';
  }
  chrome.runtime.sendMessage({ type: 'LIVE_CONSTANTS' }, (res) => {
    if (chrome.runtime.lastError) return;
    if (res && res.ok) { STATE.region=res.region; STATE.j_per_token=res.j_per_token; STATE.pue=res.pue; ensureMini(); hookInputs(); hookOutputs(); }
  });
  function estimateTokens(text){ if(!text) return 0; const lang=navigator.language||'en'; let div=4; if(/zh|ja|ko/.test(lang)) div=2.2; if(/[一-龯ぁ-ゟ゠-ヿ가-힣]/.test(text)) div=2.2; return Math.ceil(text.length/div); }
  function liveCompute(tokens){ if(!STATE.region) return {water_mL:0,co2_g:0}; const j=STATE.j_per_token*Math.max(0,tokens);
    const kIt=j/3_600_000, kSite=kIt*STATE.pue; const h=(new Date()).getHours();
    const gF=Array.isArray(STATE.region.grid_hourly_factor)?(STATE.region.grid_hourly_factor[h]??1):1;
    const wF=Array.isArray(STATE.region.wue_hourly_factor)?(STATE.region.wue_hourly_factor[h]??1):1;
    const wL=kSite*((STATE.region.wue_L_per_kWh??0.30)*wF); const cg=kSite*((STATE.region.grid_g_per_kWh??400)*gF); return {water_mL:wL*1000, co2_g:cg}; }
  function hookInputs(){ const update=()=>{ const ta=document.querySelector('textarea, textarea[aria-label], div[contenteditable="true"]'); if(!ta) return; const v=ta.value||ta.innerText||''; STATE.tokens_in=estimateTokens(v); schedule(); };
    document.addEventListener('keyup', update, {passive:true}); setInterval(update, 1000); }
  function hookOutputs(){ const obs=new MutationObserver(()=>{ let t=''; document.querySelectorAll('[data-message-author-role="assistant"], .markdown, .prose, .result-streaming').forEach(el=>{ t+=(el.innerText||''); }); STATE.tokens_out=estimateTokens(t); schedule(); });
    obs.observe(document.body,{childList:true,subtree:true,characterData:true}); }

  let box, waterEl, co2El, closeBtn, raf=false;
  async function ensureMini(){
    if (box) return;
    const style=document.createElement('style'); style.textContent=`#gq-mini{position:fixed;right:16px;bottom:16px;z-index:999999;background:rgba(15,23,42,.95);color:#e5e7eb;border:1px solid #334155;border-radius:10px;padding:8px 10px;font:13px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.25);user-select:none}#gq-mini .row{display:flex;gap:8px;align-items:center}#gq-mini .label{color:#9ca3af}#gq-mini .value{font-weight:600}#gq-mini .close{margin-left:8px;cursor:pointer;color:#94a3b8}#gq-mini.dragging{opacity:.85;cursor:move}`; document.documentElement.appendChild(style);
    box=document.createElement('div'); box.id='gq-mini'; box.innerHTML=`<div class="row"><div class="label">Water</div><div class="value"><span id="gq-water">0.00</span> mL</div><div class="label">CO₂</div><div class="value"><span id="gq-co2">0.00</span> g</div><div class="close" title="Close">✕</div></div>`; document.documentElement.appendChild(box);
    waterEl=box.querySelector('#gq-water'); co2El=box.querySelector('#gq-co2'); closeBtn=box.querySelector('.close');
    closeBtn.addEventListener('click', ()=>{ savePos(); box.remove(); box=null; });

    try { const store=await chrome.storage.local.get(['mini_pos']); const pos=store.mini_pos; if(pos&&typeof pos.left==='number'&&typeof pos.top==='number'){ box.style.left=pos.left+'px'; box.style.top=pos.top+'px'; box.style.right='auto'; box.style.bottom='auto'; } } catch{}

    let dragging=false,sx=0,sy=0,startLeft=0,startTop=0;
    box.addEventListener('mousedown', e=>{ dragging=true; box.classList.add('dragging'); sx=e.clientX; sy=e.clientY; const r=box.getBoundingClientRect(); startLeft=r.left; startTop=r.top; e.preventDefault(); });
    document.addEventListener('mousemove', e=>{ if(!dragging) return; const dx=e.clientX-sx, dy=e.clientY-sy; box.style.left=(startLeft+dx)+'px'; box.style.top=(startTop+dy)+'px'; box.style.right='auto'; box.style.bottom='auto'; });
    document.addEventListener('mouseup', ()=>{ if(!dragging) return; dragging=false; box&&box.classList.remove('dragging'); savePos(); });
    async function savePos(){ if(!box) return; const r=box.getBoundingClientRect(); try{ await chrome.storage.local.set({ mini_pos:{ left:Math.round(r.left), top:Math.round(r.top) } }); }catch{} }
  }
  function schedule(){ if(raf) return; raf=true; requestAnimationFrame(()=>{ raf=false; draw(); }); }
  function draw(){ if(!box||!STATE.region) return; const tokens=Math.max(0,STATE.tokens_in+STATE.tokens_out); const {water_mL,co2_g}=liveCompute(tokens); waterEl.textContent=water_mL.toFixed(2); co2El.textContent=co2_g.toFixed(2); }
  let finalizeTimer=null; function arm(){ clearTimeout(finalizeTimer); finalizeTimer=setTimeout(finalize,1500); }
  document.addEventListener('keydown', arm, {passive:true}); document.addEventListener('click', arm, {passive:true});
  function finalize(){ chrome.runtime.sendMessage({ type:'CALCULATE_IMPACT', site:STATE.site, model:STATE.model, tokens_in:STATE.tokens_in, tokens_out:STATE.tokens_out }, ()=>{}); }
})();