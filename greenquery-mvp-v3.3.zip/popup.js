
function $(id){ return document.getElementById(id); }

class SimpleLineChart {
  constructor(canvas, seriesA, seriesB, labels, which='both') { this.canvas=canvas; this.ctx=canvas.getContext('2d'); this.seriesA=seriesA||[]; this.seriesB=seriesB||[]; this.labels=labels||[]; this.which=which; this.draw(); }
  draw(){ const ctx=this.ctx; const W=this.canvas.width=this.canvas.clientWidth||420; const H=this.canvas.height=this.canvas.clientHeight||180; const pad=32;
    const sa=(this.which==='co2')?[]:this.seriesA; const sb=(this.which==='water')?[]:this.seriesB;
    const maxA=sa.length?Math.max(1e-6,...sa):0; const maxB=sb.length?Math.max(1e-6,...sb):0; const maxY=Math.max(1e-6,maxA,maxB);
    const toY=v=>H-pad-(v/maxY)*(H-2*pad); const toX=i=>pad+i*((W-2*pad)/Math.max(1,this.labels.length-1));
    ctx.clearRect(0,0,W,H); ctx.fillStyle='#0f172a'; ctx.fillRect(0,0,W,H); ctx.strokeStyle='#334155'; ctx.lineWidth=1;
    for(let i=0;i<4;i++){ const y=pad+i*((H-2*pad)/3); ctx.beginPath(); ctx.moveTo(pad,y); ctx.lineTo(W-pad,y); ctx.stroke(); }
    const draw=(data,color)=>{ if(data.length<2) return; ctx.strokeStyle=color; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(toX(0),toY(data[0])); for(let i=1;i<data.length;i++) ctx.lineTo(toX(i),toY(data[i])); ctx.stroke(); };
    if(this.which!=='co2') draw(sa,'#3b82f6'); if(this.which!=='water') draw(sb,'#10b981');
  }
}

// ----- Tier builders (100 tiers each) -----
function buildWaterTiers(){
  const tiers=[]; const steps=100; const max=150; const inc=max/steps;
  const pools=[
    {max:10, m:["A drop in the bucket.","Cactus-level efficiency.","Barely a sip — nice restraint.","Eco‑sip complete."]},
    {max:40, m:["Sipping sustainably.","Rinsing responsibly.","Light splash of insight.","Dishwasher‑light territory."]},
    {max:70, m:["Shower‑level thinking.","Ideas flowing freely.","Moderate soak of knowledge.","Bucket of brilliance."]},
    {max:100, m:["Long‑shower vibes — easy there.","Bathtub behavior emerging.","High tide of thought.","Consider trimming prompts."]},
    {max:130, m:["Tub nearly full — eco‑pause?","You’re in deep water.","Offset recommended.","Planet requests a towel."]},
    {max:Infinity, m:["150 L neighborhood — overflow alert.","Offset your digital thirst — the planet’s parched.","Eco‑guilt unlocked."]},
  ];
  for(let i=1;i<=steps;i++){ const thr=+(i*inc).toFixed(1); const pool=pools.find(p=>thr<=p.max).m; const extras=[`${Math.round(thr)} L — hydrated curiosity.`,`Water mark: ${Math.round(thr)} L.`]; tiers.push({threshold:thr,messages:pool.concat(extras)}); }
  return tiers;
}
function buildCarbonTiers(){
  const tiers=[]; const steps=100; const max=1000; const inc=max/steps;
  const pools=[
    {max:100, m:["Carbon‑light and clever.","Tiny digital puff.","Barely a byte of CO₂.","Cleaner than a breeze."]},
    {max:300, m:["Hot ideas, cool planet.","Phone‑charge territory.","Coffee‑level emissions.","Still in the green."]},
    {max:600, m:["Your AI’s warming up.","Laptop‑hour equivalent.","Streaming‑session vibes.","Efficient curiosity."]},
    {max:900, m:["SUV‑idle range — steady now.","High‑octane thoughts.","Offset soon, eco‑friend.","Carbon creeping upward."]},
    {max:1000, m:["1 kg CO₂ — carbon kilo club.","Offset before take‑off.","Sky sigh engaged.","Boarding call for trees."]},
    {max:Infinity, m:["Above 1 kg — jet‑set AI detected.","Offset required — planet paging you.","Guilt trip boarding now."]},
  ];
  for(let i=1;i<=steps;i++){ const thr=+(i*inc).toFixed(0); const pool=pools.find(p=>thr<=p.max).m; const extras=[`${thr} g — measured and mindful.`,`Carbon mark: ${thr} g.`]; tiers.push({threshold:thr,messages:pool.concat(extras)}); }
  return tiers;
}
const WATER_TIERS = buildWaterTiers();
const CARBON_TIERS = buildCarbonTiers();
function pickTierMessage(value, tiers){ for(let i=tiers.length-1;i>=0;i--){ if(value>=tiers[i].threshold){ const arr=tiers[i].messages; return arr[Math.floor(Math.random()*arr.length)]; } } return "Minimal footprint — keep it clean!"; }

async function rpc(type,payload={}){ return new Promise((resolve)=>{ chrome.runtime.sendMessage({type,...payload}, (res)=>{ const err=chrome.runtime.lastError; if(err){ console.warn(err.message); resolve(null); return;} resolve(res); }); }); }

function groupByDay(events){ const by=new Map(); const sod=ts=>new Date(new Date(ts).toDateString()).getTime();
  for(const e of events){ const k=sod(e.ts); const cur=by.get(k)||{water:0,co2:0}; cur.water+=(e.water_L||0); cur.co2+=(e.co2_g||0); by.set(k,cur); }
  const keys=Array.from(by.keys()).sort((a,b)=>a-b);
  return { labels:keys.map(k=>new Date(k).toLocaleDateString()), water:keys.map(k=>by.get(k).water), co2:keys.map(k=>by.get(k).co2) };
}

let recentLimit=5;

async function refreshOverview(){
  const totals=await rpc('GET_TOTALS');
  if (totals && totals.ok) {
    const tw=(totals.totals.water||0); const tc=(totals.totals.co2||0);
    $("total-water").textContent = tw.toFixed(3);
    $("total-co2").textContent = tc.toFixed(1);

    // Fun-liner callout
    const callout = $("impactCallout");
    if (callout){
      const wMsg = pickTierMessage(tw, WATER_TIERS);
      const cMsg = pickTierMessage(tc, CARBON_TIERS);
      const overWater = tw > 150; const overCO2 = tc > 1000;
      const nudge = (overWater || overCO2) ? `<div style="margin-top:6px;color:#fecaca;">Offset nudge: your usage is above the typical range.</div>` : "";
      callout.innerHTML = `<div class="row"><div>💧 ${wMsg}</div><div>🌍 ${cMsg}</div></div>${nudge}`;
      callout.style.display = "block";
    }
  }
  const recent=await rpc('GET_RECENT',{limit:Math.max(5,recentLimit)});
  const container=$("recent"); container.innerHTML='';
  if (recent && recent.ok && recent.events.length){
    $("empty").style.display='none';
    recent.events.forEach(e=>{ const div=document.createElement('div'); div.className='item';
      div.innerHTML = `<div class="row"><div>${e.site||'site'}</div><div>${new Date(e.ts).toLocaleString()}</div></div>
      <div class="row"><div>${e.model||''}</div><div>W ${e.water_L.toFixed(3)} L · CO₂ ${e.co2_g.toFixed(1)} g</div></div>`; container.appendChild(div); });
    const grouped=groupByDay(recent.events.slice().reverse());
    new SimpleLineChart($("usageChart"), grouped.water, grouped.co2, grouped.labels, 'both');
    buildImpactCards((totals?.ok?totals.totals.water:0)||0, (totals?.ok?totals.totals.co2:0)||0);
    const btn=$("offsetBtn"); if(btn) btn.onclick=()=>{ window.open("https://climateneutralnow.org/","_blank"); };
  } else { $("empty").style.display='block'; }
}

async function refreshAnalytics(){
  const recent=await rpc('GET_RECENT',{limit:500});
  const rangeDays=parseInt(($("range").value||"30"),10); const which=$("metric").value||'both';
  let events=(recent&&recent.ok)?recent.events:[]; const cutoff=Date.now()-rangeDays*24*3600*1000;
  events=events.filter(e=>e.ts>=cutoff); const grouped=groupByDay(events.slice().reverse());
  new SimpleLineChart($("analyticsChart"), grouped.water, grouped.co2, grouped.labels, which);
  const sumW=grouped.water.reduce((a,b)=>a+b,0); const sumC=grouped.co2.reduce((a,b)=>a+b,0);
  $("analyticsSummary").textContent=`Sum in range — Water: ${sumW.toFixed(3)} L · CO₂: ${sumC.toFixed(1)} g`;
}

let histPage=0;
async function refreshHistory(){
  const from=$("fromDate").value?new Date($("fromDate").value+"T00:00:00").getTime():0;
  const to=$("toDate").value?new Date($("toDate").value+"T23:59:59").getTime():Date.now();
  const site=$("siteFilter").value||'all'; const sort=$("sort").value||'newest'; const pageSize=20;
  const res=await rpc('GET_HISTORY',{since:from,until:to,site,page:histPage,pageSize,sort});
  const list=$("historyList"); list.innerHTML='';
  if(!res||!res.ok){ list.textContent='Error loading history.'; return; }
  res.rows.forEach(e=>{ const div=document.createElement('div'); div.className='item';
    div.innerHTML = `<div class="row"><div>${e.site||''}</div><div>${new Date(e.ts).toLocaleString()}</div></div>
    <div class="row"><div>${e.model||''}</div><div>W ${e.water_L.toFixed(3)} L · CO₂ ${e.co2_g.toFixed(1)} g</div></div>`; list.appendChild(div); });
  $("pageInfo").textContent=`Page ${res.page+1} of ${Math.max(1, Math.ceil(res.count/res.pageSize))}`;
}

// Impact cards and offset CTA
function formatNum(n,d=2){ return Number(n).toLocaleString(undefined,{maximumFractionDigits:d}); }
function buildImpactCards(totalWaterL,totalCO2g){
  const host=$("impact"); if(!host) return; host.innerHTML='';
  const BOTTLE_ML=500, SHOWER_L=65, BATHTUB_L=150, POOL_L=50000, DRIVE_G_PER_KM=120, TREE_KG_PER_YEAR=21;
  const cards=[];
  const bottles=(totalWaterL*1000)/BOTTLE_ML; cards.push({icon:'🧴', title:'Bottles of water', value:`${formatNum(bottles,0)} × 500 mL`});
  const showers=totalWaterL/SHOWER_L; cards.push({icon:'🚿', title:'Showers', value:`${formatNum(showers,1)} showers`});
  const baths=totalWaterL/BATHTUB_L; cards.push({icon:'🛁', title:'Bathtubs', value:`${formatNum(baths,2)} tubs`});
  if (totalWaterL>=POOL_L/20){ const pools=totalWaterL/POOL_L; cards.push({icon:'🏊', title:'Swimming pools', value:`${formatNum(pools,3)} pools`}); }
  const km=(totalCO2g)/DRIVE_G_PER_KM; cards.push({icon:'🚗', title:'Driving distance', value:`${formatNum(km,1)} km`});
  const trees_years=(totalCO2g/1000)/TREE_KG_PER_YEAR; cards.push({icon:'🌳', title:'Tree-years to absorb', value:`${formatNum(trees_years,2)} tree·years`});
  cards.slice(0,6).forEach(c=>{ const el=document.createElement('div'); el.className='item'; el.innerHTML=`<div class="row"><div>${c.icon} ${c.title}</div><div style="font-weight:600;">${c.value}</div></div>`; host.appendChild(el); });
  const showOffset=(totalWaterL>=1000)||(totalCO2g>=10000); const box=$("offsetBox"); if(box) box.style.display=showOffset?'block':'none';
}

async function loadSettings(){
  const res=await rpc('GET_SETTINGS'); if(!res||!res.ok) return; const s=res.settings||{};
  $("regionSource").value=s.region_source||'auto'; $("regionCode").value=s.region_code||''; $("jPerToken").value=s.j_per_token??3.5; $("pue").value=s.pue??1.2; $("wue").value=s.wue_L_per_kWh??''; $("grid").value=s.grid_g_per_kWh??'';
  $("settingsInfo").textContent=`Detected region: ${res.region?.code||'DEFAULT'} · WUE ${res.region?.wue_L_per_kWh??'—'} · Grid ${res.region?.grid_g_per_kWh??'—'}`;
}
async function saveSettings(){
  const payload={ region_source:$("regionSource").value, region_code:($("regionCode").value||'').trim()||null, j_per_token:parseFloat($("jPerToken").value)||3.5, pue:parseFloat($("pue").value)||1.2, wue_L_per_kWh:$("wue").value===''?null:parseFloat($("wue").value), grid_g_per_kWh:$("grid").value===''?null:parseFloat($("grid").value) };
  const res=await rpc('SET_SETTINGS',{settings:payload}); if(res&&res.ok){ $("settingsInfo").textContent='Settings saved.'; setTimeout(loadSettings,300); }
}
async function resetSettings(){ const res=await rpc('SET_SETTINGS',{settings:{region_source:'auto',region_code:null,j_per_token:3.5,pue:1.2,wue_L_per_kWh:null,grid_g_per_kWh:null}}); if(res&&res.ok) loadSettings(); }
async function clearData(){ if(!confirm('Delete all stored GreenQuery data? This cannot be undone.')) return; const res=await rpc('CLEAR_DATA'); if(res&&res.ok){ $("settingsInfo").textContent='All data deleted.'; refreshOverview(); if(document.querySelector('.tab.active')?.getAttribute('data-tab')==='history') refreshHistory(); } }

document.addEventListener('DOMContentLoaded', ()=>{
  // Tabs
  const tabs=document.querySelectorAll('.tab');
  tabs.forEach(t=>t.addEventListener('click', ()=>{ tabs.forEach(x=>x.classList.remove('active')); t.classList.add('active');
    document.querySelectorAll('.view').forEach(v=>v.classList.remove('active')); const id=t.getAttribute('data-tab'); $(id).classList.add('active');
    if(id==='overview') refreshOverview(); if(id==='analytics') refreshAnalytics(); if(id==='history') refreshHistory(); if(id==='settings') loadSettings();
  }));
  // Init
  refreshOverview();
  $("exportBtn").addEventListener('click', async ()=>{ const res = await rpc('EXPORT_CSV'); if(!res||!res.ok) return; const blob=new Blob([res.csv],{type:'text/csv;charset=utf-8;'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='greenquery_export.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000); });
  $("range").addEventListener('change', refreshAnalytics); $("metric").addEventListener('change', refreshAnalytics);
  $("applyHistory").addEventListener('click',()=>{ window.histPage=0; refreshHistory(); }); $("prevPage").addEventListener('click',()=>{ if(window.histPage>0){ window.histPage--; refreshHistory(); } }); $("nextPage").addEventListener('click',()=>{ window.histPage++; refreshHistory(); });
  $("saveSettings").addEventListener('click', saveSettings); $("resetSettings").addEventListener('click', resetSettings); $("clearData").addEventListener('click', clearData); $("loadMoreRecent").addEventListener('click', ()=>{ window.recentLimit=(window.recentLimit||5)+5; refreshOverview(); });
});
